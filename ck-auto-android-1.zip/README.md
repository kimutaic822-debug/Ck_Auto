# CK Auto Android app
WebView app (the CK Auto screens) plus native USSD, SMS and background service.
Build: the GitHub workflow runs `gradle assembleDebug` and publishes app-debug.apk.
First run: Settings > Allow permissions, then Turn on USSD service (Accessibility).
