# CK Auto Android app
WebView app (the CK Auto screens) plus native USSD, SMS and background service.
Build: the GitHub workflow runs `gradle assembleDebug` and publishes app-debug.apk.
First run: Settings > Allow permissions, then Turn on USSD service (Accessibility).

v2.0: alternative offers (fallback), retry keys, sleep mode, till wallet balance, no repeat of same amount per day, price prompt after setup.
v2.1: custom offer builder (start code + steps, quick paste, screenshots per step).
v2.2: Verify offers (follows route, checks final step, presses Cancel; test number 0722756764).
